package com.adobe.aem.onlineshopping.core.services.impl;
import com.adobe.aem.onlineshopping.core.config.CommonConfiguration;
import com.adobe.aem.onlineshopping.core.services.ProductService;
import com.adobe.aem.onlineshopping.core.services.UtilityService;
import com.google.gson.JsonObject;
import org.json.JSONObject;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Component(service = ProductService.class)
@Designate(ocd= CommonConfiguration.class)
public class ProductServiceImpl implements ProductService {

    private static final Logger LOG = LoggerFactory.getLogger(ProductService.class);
    private CommonConfiguration config;

    @Reference
    UtilityService utilityService;

    @Activate
    protected void activate(CommonConfiguration config) {
        this.config = config;
    }

    @Override
    public JSONObject getProductsData() {
        LOG.info("----------< Reading the config values >----------");
        JSONObject jsonResponse = null;
            String protocol = config.getProtocol();
            String server = config.getServer();
            String endpoint = config.getEndpoint();
            String url = protocol + "://" + server + "/" + endpoint;
            LOG.info("URL is ; "+url);
            String response = utilityService.getAPIResponse(url);
            JSONObject jsonResp = utilityService.getJsonObject(response);
            LOG.info(" --- JSON Response --- " + jsonResp);
        return jsonResponse;
    }

    @Override
    public JsonObject getProductDetailsByProductId(String productId) {
        String protocol = config.getProtocol();
        String server = config.getServer();
        String endpoint = config.getEndpoint();
        String url = protocol + "://" + server + "/" + endpoint;
        LOG.info("URL is ; "+url);
        return null;
    }

}